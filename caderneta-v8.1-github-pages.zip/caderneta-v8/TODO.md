# Checklist · piloto Eunápolis V8 (meta: 40 pontos)

## Cadastro dos 40 pontos

- [ ] Completar os dados dos 24 pontos que ainda não constam nos 16 registros locais da V7.
- [ ] Para cada novo ponto, obter nome oficial, categoria, fonte, endereço, coordenada e tipo de coordenada.
- [ ] Marcar evidência/status (`pendente`, `validado`, `suspenso` ou `fora_da_edicao`) e guardar data da verificação.
- [ ] Não criar nome, coordenada, horário, acesso ou rota por inferência.
- [ ] Manter o frontend e a tabela `pontos` sincronizados; registrar código EU-### estável.

## Antes de testar com participantes

- [ ] Vistoriar os 40 pontos e completar uma ficha de campo por ponto.
- [ ] Confirmar responsável, autorização, acesso, horário, piso, travessias, iluminação, acessibilidade conhecida e riscos.
- [ ] Medir e testar a rota; não publicar a lista como instrução de navegação antes da validação.
- [ ] Substituir os cinco códigos de demonstração por segredos aleatórios e revogáveis antes de instalação.
- [ ] Testar autenticação, carimbo e banco com contas e dados fictícios.
- [ ] Definir consentimento, privacidade, suporte, backups e resposta a incidentes.

## Limites

A V8 contém somente Eunápolis. A meta de 40 é uma meta de cadastro, não afirma que 40 pontos já estejam informados ou validados. Nenhum ponto deve ser publicado sem evidência e checagem local.
