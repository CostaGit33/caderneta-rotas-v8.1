export const CITY = {
  id: "eunapolis",
  name: "Eunápolis",
  state: "BA",
  ibgeCode: "2910727",
  region: "Extremo Sul da Bahia",
  season: "Piloto de validação · Eunápolis",
  totalPoints: 40,
  targetPoints: 40,
  demoPoints: 16,
  mapCenter: { center: [-16.3766, -39.5864], zoom: 14 },
};

export const CATEGORIES = [
  { id: "historia", name: "História", icon: "⌂", color: "red", description: "Memória e patrimônio local" },
  { id: "praias", name: "Praias", icon: "≈", color: "blue", description: "Áreas de lazer e paisagem local" },
  { id: "natureza", name: "Natureza", icon: "❋", color: "green", description: "Áreas verdes e paisagens locais" },
  { id: "caminhos", name: "Caminhos", icon: "⌁", color: "blue", description: "Caminhada e deslocamentos locais" },
  { id: "cultura", name: "Cultura", icon: "✳", color: "ochre", description: "Arte, encontros e tradições locais" },
  { id: "sabores", name: "Sabores", icon: "✦", color: "red", description: "Mercados e experiências locais" },
];

export const EUNAPOLIS_DESTINATION = {
  id: "eunapolis",
  name: "Eunápolis",
  region: "Bahia · código IBGE 2910727",
  summary: "O antigo Km 64 cresceu no encontro das ligações BR-367 e BR-101. Emancipada em 1988, Eunápolis reúne uma edição-piloto com meta de 40 pontos para cadastro, teste e validação local.",
  targetPoints: 40,
  facts: [
    { label: "Emancipação", value: "12 mai. 1988", detail: "Criação do município" },
    { label: "População", value: "113.710", detail: "Censo 2022 · IBGE" },
    { label: "Meta da edição", value: "40 pontos", detail: "Cadastro e validação local" },
  ],
  pilotNote: "A V8 mantém os pontos locais documentados e deixa pendente o cadastro de informações ainda não fornecidas. A meta de 40 não significa que todos estejam identificados, coordenados ou validados. Coordenadas, acesso, horários, segurança, autorização de QR e operação exigem confirmação presencial.",
  sources: [
    { label: "Dados municipais · Prefeitura de Eunápolis", url: "https://www.eunapolis.ba.gov.br/site/dadosmunicipais" },
    { label: "Dados municipais · IBGE", url: "https://www.ibge.gov.br/cidades-e-estados/ba/eunapolis.html" },
    { label: "Praça da Liberdade · Prefeitura de Eunápolis", url: "https://www.eunapolis.ba.gov.br/Site/Noticias/noticia-180720251513201633-Prefeitura-requalifica-Pra-a-da-Liberdade-e-espa-o-volta-a-ser-local-de-l" },
    { label: "Praças do Pequi e Parque da Renovação · Prefeitura de Eunápolis", url: "https://www.eunapolis.ba.gov.br/site/Noticias/noticia-220420260959481633-Prefeitura-de-Eun-polis-investe-na-revitaliza-o-das-Pra-as-do-Pequi-e-Par" },
    { label: "Parque Gravatá · Câmara Municipal de Eunápolis", url: "https://www.camaraeunapolis.ba.gov.br/site/Noticias/noticia-190320251006002476-Vereador-pede-revitaliza-o-do-Parque-Ecol-gico-do-Gravat-em-Eun-polis" },
    { label: "Viola de Bolso · fonte institucional", url: "https://violadebolso.org.br/about/" },
    { label: "Radar64 · notícias locais de Eunápolis", url: "https://radar64.com/" },
  ],
};

export const CITY_OPTIONS = [
  { id: "eunapolis", name: "Eunápolis", description: "Cidade piloto · meta de 40 pontos" },
];

export const JOURNEY_DAYS = 90;
export const JOURNEY_NAME = "Caminhos de Eunápolis";
export const JOURNEY_STAGES = [
  { id: "eunapolis-descoberta", cityId: "eunapolis", cityName: "Eunápolis", subtitle: "Registre descobertas nos pontos da edição-piloto.", kind: "new-points", target: 2 },
  { id: "eunapolis-validacao", cityName: "Eunápolis", subtitle: "Conclua verificações locais necessárias para a edição.", kind: "milestones", milestones: [
    { id: "eunapolis-fonte", title: "Uma fonte local conferida" },
    { id: "eunapolis-campo", title: "Um ponto validado em campo" },
    { id: "eunapolis-qr", title: "Um teste de QR registrado" },
  ] },
];

// Os itens são candidatos documentados em Eunápolis; status e coordenadas não equivalem a aprovação de campo.
export const POINTS = [
  { id: "EU-001", name: "Praça da Bandeira", categoryIds: ["historia", "cultura"], icon: "✳", x: 42, y: 34, lat: -16.3751286, lng: -39.5881012, coordinateKind: "map_reference", mapSource: "OpenStreetMap", note: "Uso cívico documentado. Referência cartográfica; confirmar coordenada, acesso, segurança e operação presencialmente.", hidden: false },
  { id: "EU-002", name: "Praça da Liberdade", categoryIds: ["cultura", "natureza"], icon: "✳", x: 57, y: 28, lat: -16.373437, lng: -39.5905262, coordinateKind: "map_reference", mapSource: "OpenStreetMap", note: "Espaço central requalificado. Referência cartográfica; confirmar coordenada, acesso, segurança e operação presencialmente.", hidden: false },
  { id: "EU-003", name: "Parque Ecológico do Gravatá", categoryIds: ["natureza", "caminhos"], icon: "❋", x: 34, y: 48, coordinateKind: "pending", note: "Parque urbano descrito com dois lagos naturais e pista de caminhada. Coordenada, condições atuais, horário e acesso devem ser conferidos em campo.", hidden: false },
  { id: "EU-004", name: "Praça do Pequi", categoryIds: ["cultura", "sabores"], icon: "✦", x: 69, y: 42, lat: -16.3714765, lng: -39.5779847, coordinateKind: "map_reference", mapSource: "OpenStreetMap", note: "Praça pública com intervenções municipais documentadas. Referência cartográfica; confirmar coordenada, acesso, segurança e operação presencialmente.", hidden: false },
  { id: "EU-005", name: "Praça do Parque da Renovação", categoryIds: ["cultura", "natureza"], icon: "✳", x: 78, y: 55, coordinateKind: "pending", note: "Espaço de bairro citado em intervenção municipal; endereço e operação ainda precisam de confirmação.", hidden: false },
  { id: "EU-006", name: "Praça da Colônia", categoryIds: ["cultura", "caminhos"], icon: "⌂", x: 24, y: 73, coordinateKind: "pending", note: "Praça requalificada no distrito de Colônia; confirmar endereço, acesso e condição atual.", hidden: false },
  { id: "EU-007", name: "Praça Dona Dinah Borges Moura", categoryIds: ["natureza", "caminhos"], icon: "≈", x: 63, y: 67, coordinateKind: "pending", note: "Praça inaugurada com pista de caminhada de 160 m; validar condição atual.", hidden: false },
  { id: "EU-008", name: "Lagoa e Academia da Saúde do Dinah Borges", categoryIds: ["natureza", "caminhos"], icon: "❋", x: 73, y: 75, coordinateKind: "pending", note: "Pista de caminhada documentada em restauração, sem quilometragem oficial publicada.", hidden: false },
  { id: "EU-009", name: "Mercado Municipal Dona Alzira", categoryIds: ["sabores", "cultura"], icon: "✦", x: 49, y: 43, coordinateKind: "pending", note: "Feira do Bueiro tradicional; reforma, endereço e horário atual precisam de confirmação.", hidden: false },
  { id: "EU-010", name: "Feira Livre Juca Rosa", categoryIds: ["sabores", "cultura"], icon: "✦", x: 84, y: 36, coordinateKind: "pending", note: "Localização secundária por diretório; validar calendário e funcionamento.", hidden: false },
  { id: "EU-011", name: "Viola de Bolso Arte e Memória", categoryIds: ["cultura", "historia"], icon: "▤", x: 55, y: 82, coordinateKind: "pending", note: "Ponto de cultura com oficinas e vivências; confirmar endereço, responsável, funcionamento e autorização.", hidden: false },
  { id: "EU-012", name: "Prado da Rua Paulo de Tarso", categoryIds: ["cultura", "historia"], icon: "⌂", x: 29, y: 88, coordinateKind: "pending", note: "A corrida de cavalo é patrimônio cultural imaterial municipal; validar operação e visitação.", hidden: false },
  { id: "EU-013", name: "Estrada da Colônia · ciclofaixa", categoryIds: ["caminhos", "natureza"], icon: "⌁", x: 17, y: 61, coordinateKind: "pending", note: "Cerca de 6 km demarcados em via de tráfego misto; endpoints e segurança pendentes. Não é rota validada.", hidden: false },
  { id: "EU-014", name: "Circuito Sesc de Corridas", categoryIds: ["caminhos", "cultura"], icon: "➜", x: 46, y: 20, coordinateKind: "pending", evidenceKind: "evento_temporal", note: "Referência a evento temporal; não tratar como circuito cotidiano ou ponto permanente sem revisão da edição e da data.", hidden: false },
  { id: "EU-017", name: "Cruz da primeira missa · proposta", categoryIds: ["historia"], icon: "?", x: 37, y: 25, coordinateKind: "pending", evidenceKind: "proposta_editorial", note: "Marco proposto; a sanção final do projeto e a localização precisam de confirmação.", hidden: true },
  { id: "EU-019", name: "Track comunitário de pedal · candidato", categoryIds: ["caminhos"], icon: "⌁", x: 14, y: 31, coordinateKind: "pending", evidenceKind: "informacao_insuficiente", note: "Candidato comunitário sem validação de acesso, superfície, traçado ou segurança.", hidden: true },
];

export const ROUTES = [
  { id: "eu-gravata", name: "Circuito Gravatá · proposta", subtitle: "Natureza urbana e caminhada", icon: "❋", color: "green", evidenceKind: "proposta_editorial", note: "Geometria, acesso e operação pendentes; não usar como navegação.", pointIds: ["EU-003", "EU-007", "EU-008"] },
  { id: "eu-cultural-central", name: "Circuito cultural central · proposta", subtitle: "Praças, mercado e cultura local", icon: "✳", color: "ochre", evidenceKind: "proposta_editorial", note: "Sequência editorial; distância, conexão e segurança não validadas.", pointIds: ["EU-001", "EU-002", "EU-004", "EU-009", "EU-011"] },
  { id: "eu-colonia", name: "Caminho da Colônia · pendente", subtitle: "Ciclofaixa e caminhos locais", icon: "⌁", color: "blue", evidenceKind: "informacao_insuficiente", note: "Extremos, traçado, tráfego e segurança precisam de verificação em campo.", pointIds: ["EU-006", "EU-013", "EU-003", "EU-019"] },
];

export const COLLECTIONS = [
  { id: "eu-cidade", name: "Eunápolis · pontos locais", subtitle: "16 registros existentes · meta de 40 pontos", icon: "✦", color: "ochre", pointIds: POINTS.map((point) => point.id) },
  { id: "eu-patrimonio", name: "Memória e cultura", subtitle: "Pontos e referências culturais locais", icon: "⌂", color: "red", pointIds: ["EU-001", "EU-002", "EU-004", "EU-009", "EU-011", "EU-012", "EU-017"] },
  { id: "eu-natureza", name: "Natureza e caminhos", subtitle: "Áreas verdes e caminhos locais", icon: "❋", color: "green", pointIds: ["EU-003", "EU-006", "EU-007", "EU-008", "EU-013", "EU-019"] },
];

export function setActiveCity() { return CITY; }
export function getPoint(id) { return POINTS.find((point) => point.id === id); }
export function findPointAnyCity(code) {
  const id = String(code || "").toUpperCase();
  const point = POINTS.find((item) => item.id === id);
  return point ? { point, cityId: CITY.id } : null;
}
export function getCategory(id) { return CATEGORIES.find((category) => category.id === id); }
