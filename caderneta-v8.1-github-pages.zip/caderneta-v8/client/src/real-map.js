import L from "leaflet";
import "leaflet/dist/leaflet.css";

const CITY_CENTERS = {
  eunapolis: { center: [-16.3766, -39.5864], zoom: 14 },
};

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

function statusLabel(state, point) {
  if (state.conquered.includes(point.id)) return "Conquistado";
  if (point.hidden && !state.discovered.includes(point.id)) return "Mistério";
  return "Disponível";
}

function coordinateLabel(point) {
  if (point.coordinateKind === "area_anchor") return "âncora geográfica de área";
  if (point.coordinateKind === "map_reference") return "referência cartográfica · confirmar em campo";
  return "coordenada de campo";
}

function coordinateClass(point) {
  if (point.coordinateKind === "area_anchor") return "area-anchor";
  if (point.coordinateKind === "map_reference") return "map-reference";
  return "exact-coordinate";
}

export function mountRealMap({ element, city, points, state, onOpenPoint }) {
  if (!element) return null;
  const mapConfig = city.mapCenter || CITY_CENTERS[city.id] || CITY_CENTERS.eunapolis;
  const mappedPoints = points.filter((point) => Number.isFinite(point.lat) && Number.isFinite(point.lng));
  const map = L.map(element, { zoomControl: true, scrollWheelZoom: false, minZoom: 10, maxZoom: 18 }).setView(mapConfig.center, mapConfig.zoom);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors · tiles OSM.de',
    maxZoom: 19,
  }).addTo(map);

  const bounds = [];
  mappedPoints.forEach((point) => {
    const status = statusLabel(state, point);
    const color = status === "Conquistado" ? "#2f6f55" : status === "Mistério" ? "#bd8a3c" : "#2f5f73";
    const marker = L.circleMarker([point.lat, point.lng], {
      radius: 9,
      color: "#172329",
      weight: point.coordinateKind === "area_anchor" ? 3 : 2,
      dashArray: point.coordinateKind === "area_anchor" ? "4 3" : undefined,
      fillColor: color,
      fillOpacity: 0.92,
    }).addTo(map);
    marker.getElement()?.classList.add(`real-map-marker--${coordinateClass(point)}`);
    marker.bindTooltip(`${point.id} · ${point.name}${point.coordinateKind === "area_anchor" ? " · âncora" : ""}`, { direction: "top", offset: [0, -8] });
    const source = point.mapSource ? `Fonte: ${escapeHtml(point.mapSource)}` : "Fonte geográfica não registrada";
    const caution = point.note ? `<br><small>${escapeHtml(point.note)}</small>` : "";
    marker.bindPopup(`<strong>${escapeHtml(point.id)} · ${escapeHtml(point.name)}</strong><br><span>${status} · ${coordinateLabel(point)}</span><br><small>${source}</small>${caution}`);
    marker.on("click", () => onOpenPoint(point.id));
    bounds.push([point.lat, point.lng]);
  });
  if (bounds.length > 1) map.fitBounds(bounds, { padding: [24, 24], maxZoom: 15 });
  window.setTimeout(() => map.invalidateSize(), 0);
  return map;
}
