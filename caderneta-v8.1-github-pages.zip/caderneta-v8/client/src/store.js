import {
  createJourneyState,
  journeyClock,
  normalizeJourneyState,
  recordJourneyMilestone as recordJourneyMilestoneState,
  recordJourneyPoint as recordJourneyPointState,
  refreshJourneyCycle,
  startJourneyCycle,
} from "./journey.js";
import { findPointAnyCity, POINTS, setActiveCity } from "./data.js";

const STORAGE_KEY = "caderneta-eunapolis:v1";
const POINT_IDS = new Set(POINTS.map((point) => point.id));

function makeInitialState() {
  setActiveCity("eunapolis");
  const now = Date.now();
  return {
    version: 3,
    user: { number: "0001", name: "Viajante" },
    cityId: "eunapolis",
    theme: "light",
    conquered: [],
    discovered: [],
    history: [],
    account: null,
    session: false,
    journey: createJourneyState(),
    journeys: {},
    updatedAt: new Date(now).toISOString(),
  };
}

function normalizeState(value) {
  const initial = makeInitialState();
  if (!value || typeof value !== "object" || ![1, 2, 3].includes(value.version)) return initial;
  const conquered = Array.isArray(value.conquered)
    ? [...new Set(value.conquered.filter((id) => typeof id === "string" && POINT_IDS.has(id)))] : [];
  const discovered = Array.isArray(value.discovered)
    ? [...new Set([...value.discovered, ...conquered].filter((id) => typeof id === "string" && POINT_IDS.has(id)))] : [...conquered];
  const history = Array.isArray(value.history)
    ? value.history.filter((entry) => entry && typeof entry.pointId === "string" && POINT_IDS.has(entry.pointId) && typeof entry.at === "string").slice(-100)
    : [];
  setActiveCity("eunapolis");
  const journey = normalizeJourneyState(value.cityId === "eunapolis" ? value.journey : value.journeys?.eunapolis);
  return {
    version: 3,
    user: { number: String(value.user?.number || "0001"), name: String(value.user?.name || "Viajante").slice(0, 36) },
    cityId: "eunapolis",
    theme: value.theme === "dark" ? "dark" : "light",
    conquered,
    discovered,
    history,
    account: normalizeAccount(value.account),
    session: !!normalizeAccount(value.account) && value.session === true,
    journey,
    journeys: {},
    updatedAt: typeof value.updatedAt === "string" ? value.updatedAt : new Date().toISOString(),
  };
}

function parseStoredState(raw) {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw);
    if (!value || typeof value !== "object" || ![1, 2, 3].includes(value.version)) return null;
    if (!Array.isArray(value.conquered) || !Array.isArray(value.discovered) || !Array.isArray(value.history)) return null;
    return normalizeState(value);
  } catch { return null; }
}

function save(state) {
  const next = { ...state, version: 3, cityId: "eunapolis", updatedAt: new Date().toISOString() };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    return next;
  } catch (error) {
    console.warn("Não foi possível persistir a caderneta neste navegador.", error);
    return next;
  }
}

export function loadState() {
  try {
    const current = parseStoredState(localStorage.getItem(STORAGE_KEY));
    if (current) return save(current);
    // Migra o estado antigo desta origem, mas retém somente IDs do catálogo Eunápolis.
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (!key || key === STORAGE_KEY || !/^(caderneta-|mais1km-)/.test(key)) continue;
      const legacy = parseStoredState(localStorage.getItem(key));
      if (legacy) return save(legacy);
    }
    return save(makeInitialState());
  } catch (error) {
    console.warn("Estado local inválido; iniciando uma caderneta limpa de Eunápolis.", error);
    return save(makeInitialState());
  }
}

export function claimPoint(state, pointId) {
  if (!POINT_IDS.has(pointId) || state.conquered.includes(pointId)) return { state, alreadyClaimed: state.conquered.includes(pointId) };
  const next = save({
    ...state,
    conquered: [...state.conquered, pointId],
    discovered: [...new Set([...state.discovered, pointId])],
    history: [...state.history, { pointId, at: new Date().toISOString(), kind: "point" }].slice(-100),
  });
  return { state: next, alreadyClaimed: false };
}

export function recordJourneyPoint(state, pointId, now = Date.now(), pointCityId = "eunapolis") {
  if (!POINT_IDS.has(pointId) || pointCityId !== "eunapolis") return { journey: state.journey, state };
  const currentJourney = refreshJourneyCycle(state.journey, now);
  const currentState = currentJourney === state.journey ? state : save({ ...state, journey: currentJourney });
  const result = recordJourneyPointState(currentState.journey, pointId, "eunapolis", now);
  if (result.journey === currentState.journey) return { ...result, state: currentState };
  return { ...result, state: save({ ...currentState, journey: result.journey }) };
}

export function recordJourneyMilestone(state, milestoneId, now = Date.now()) {
  const currentJourney = refreshJourneyCycle(state.journey, now);
  const currentState = currentJourney === state.journey ? state : save({ ...state, journey: currentJourney });
  const result = recordJourneyMilestoneState(currentState.journey, milestoneId, now);
  if (result.journey === currentState.journey) return { ...result, state: currentState };
  return { ...result, state: save({ ...currentState, journey: result.journey }) };
}

export function startJourney(state, now = Date.now()) {
  const priorJourney = state.journey || createJourneyState();
  const currentJourney = refreshJourneyCycle(priorJourney, now);
  const currentState = currentJourney === state.journey ? state : save({ ...state, journey: currentJourney });
  const journey = startJourneyCycle(currentJourney, now);
  if (journey === currentState.journey) return currentState;
  return save({ ...currentState, journey });
}

export function refreshJourney(state, now = Date.now()) {
  const journey = refreshJourneyCycle(state.journey || createJourneyState(), now);
  if (journey === state.journey) return state;
  return save({ ...state, journey });
}
export { journeyClock };

export function revealPoint(state, pointId) {
  if (!POINT_IDS.has(pointId) || state.discovered.includes(pointId)) return state;
  return save({ ...state, discovered: [...state.discovered, pointId] });
}

export function setCity(state, _cityId) {
  if (state.cityId === "eunapolis") return state;
  setActiveCity("eunapolis");
  return save({ ...state, cityId: "eunapolis", journeys: {}, journey: createJourneyState() });
}

export function setTheme(state, theme) {
  return save({ ...state, theme: theme === "dark" ? "dark" : "light" });
}

export function resetDemo(current = null) {
  try { localStorage.removeItem(STORAGE_KEY); } catch {}
  const fresh = makeInitialState();
  const account = current?.account || null;
  return save({
    ...fresh,
    account,
    session: !!account && current?.session === true,
    user: account ? { ...fresh.user, name: account.nome } : fresh.user,
  });
}

function normalizeAccount(value) {
  if (!value || typeof value !== "object") return null;
  const nome = String(value.nome || "").trim().slice(0, 36);
  const email = String(value.email || "").trim().toLowerCase().slice(0, 120);
  if (nome.length < 2 || !email || typeof value.salt !== "string" || typeof value.hash !== "string") return null;
  return { nome, email, salt: value.salt, hash: value.hash, alg: value.alg === "fnv1a" ? "fnv1a" : "sha256", criadoEm: typeof value.criadoEm === "string" ? value.criadoEm : new Date().toISOString() };
}

export const isSignedIn = (state) => !!(state.account && state.session);
export function createAccount(state, account) { return save({ ...state, account, session: true, user: { ...state.user, name: account.nome } }); }
export function signIn(state) { return save({ ...state, session: true, user: { ...state.user, name: state.account.nome } }); }
export function signOut(state) { return save({ ...state, session: false }); }
export function updateAccount(state, patch) {
  const account = { ...state.account, ...patch };
  return save({ ...state, account, user: { ...state.user, name: account.nome } });
}

// Importa apenas carimbos de tags presentes no catálogo municipal atual.
export function importServerStamps(state, items) {
  let next = state;
  let imported = 0;
  for (const { codigo, at } of items) {
    const found = findPointAnyCity(codigo);
    const ms = Date.parse(at);
    if (!found || found.cityId !== "eunapolis" || !Number.isFinite(ms) || next.conquered.includes(found.point.id)) continue;
    const id = found.point.id;
    next = {
      ...next,
      conquered: [...next.conquered, id],
      discovered: [...new Set([...next.discovered, id])],
      history: [...next.history, { pointId: id, at: new Date(ms).toISOString(), kind: "point" }].sort((a, b) => Date.parse(a.at) - Date.parse(b.at)).slice(-100),
    };
    imported += 1;
    if (next.journey.startedAt && ms >= Date.parse(next.journey.startedAt)) next = recordJourneyPoint(next, id, ms, "eunapolis").state;
  }
  return imported ? { state: save(next), imported } : { state, imported: 0 };
}
