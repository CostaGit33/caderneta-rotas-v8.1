# V8 · escopo técnico do piloto Eunápolis

## Objetivo

Reduzir a aplicação a um único município e preparar o catálogo e banco para a meta de cadastro de 40 pontos locais, preservando apenas informação atribuída a Eunápolis.

## Entregue nesta versão

- Identidade da interface, seleção local, mapa e jornada fixos em Eunápolis.
- 16 registros locais documentados preservados, sem completar dados ausentes por invenção.
- Meta 40 explícita no cadastro municipal do banco e no guia da interface.
- Tabela `cidades` e tabela `pontos` com ID, nome, categorias, coordenadas, tipo, evidência, fonte, observação e status.
- Seed de cinco tags QR de teste; todas pendentes.
- Foco em pendências de validação presencial e execução segura de teste.

## Não é declarado nesta versão

- Que os 40 pontos já estejam cadastrados.
- Que uma referência de mapa seja coordenada de campo.
- Que a rota, acesso, segurança, horários, acessibilidade ou QR estejam aprovados.
- Que carimbo local ou QR prove presença física.

## Próximos insumos necessários

Para completar o catálogo de 40, fornecer para cada novo ponto: nome, categoria, endereço ou referência, fonte, coordenada se disponível, tipo de coordenada, evidência e ressalvas. Dados ausentes permanecem `pendente`.
