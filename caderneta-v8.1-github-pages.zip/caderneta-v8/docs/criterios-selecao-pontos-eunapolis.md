# Critérios de cadastro e validação — 40 pontos em Eunápolis

## Regra de cadastro

A meta é manter 40 registros locais úteis, não atingir 40 preenchendo dados fictícios. Cada ponto deve ter nome e referência identificáveis, categoria, fonte, evidência, status e data de atualização. Campos desconhecidos permanecem nulos ou `pendente`.

## Critérios eliminatórios para publicação

1. Existência e nome confirmados por fonte primária ou responsável local.
2. Endereço/localização inequívocos.
3. Coordenada conferida em campo e precisão registrada; distinguir ponto de âncora de área.
4. Acesso, horário e autorização confirmados.
5. Responsável definido para comunicar obra, fechamento, mudança ou remoção de QR.
6. Riscos de tráfego, piso, travessias, iluminação e ambiente avaliados.
7. Instalação de QR autorizada, legível, protegida e revogável.
8. Conectividade testada em horários distintos e em mais de um aparelho.
9. Nenhuma promessa de rota, acessibilidade ou funcionamento sem verificação.

Ponto que falhar em requisito fica `pendente`, `suspenso` ou `fora_da_edicao`.

## Pontuação editorial (100 pontos)

| Dimensão | Pontos | Evidência |
|---|---:|---|
| Fonte e evidência | 20 | Fonte primária e confirmação local |
| Validação em campo | 20 | Nome, endereço, coordenada, acesso e condição registrados |
| Autorização e responsável | 15 | Autorização e contato operacional |
| Acesso e segurança | 15 | Piso, travessias, iluminação, riscos e acessibilidade conhecida |
| QR e infraestrutura | 10 | QR testável, protegido e substituível |
| Valor para o usuário | 10 | Experiência local clara |
| Integração em rota | 5 | Conexão medida e revisada |
| Diversidade | 5 | Categoria útil sem redundância excessiva |
| **Total** | **100** | **75+ e zero falha eliminatória** |

## Ficha por ponto

```text
point_id:
nome oficial:
categoria:
endereço ou referência:
latitude / longitude / precisão:
tipo: ponto_exato | âncora_de_área | pendente
fonte e evidência:
data da vistoria:
responsável e contato:
autorização de acesso e QR:
horário/acesso:
piso, travessias e iluminação:
acessibilidade conhecida:
riscos e restrições:
local do QR:
conectividade em três testes:
foto (sem expor pessoas sem consentimento):
validado por:
nota final:
status: pendente | validado | suspenso | fora_da_edicao
valid_until:
```

## Rota

A lista de pontos não é rota navegável. Antes de publicar uma rota, registrar origem/destino, geometria, distância e data de medição, modal, piso, tráfego, travessias, iluminação, acessibilidade, permissões, riscos e procedimento de suspensão.
