# Verificação da V8 · Eunápolis

## Escopo verificado

- Cidade ativa única: Eunápolis (`eunapolis`, Bahia, IBGE 2910727).
- Meta configurada no catálogo, no progresso principal e no banco: 40 pontos.
- Catálogo: 16 registros locais documentados preservados da V7; não apresentados como 40 locais confirmados.
- Banco: cadastro municipal e tabela de pontos; cinco tags de teste, todas `pendente`.
- Seleção de cidade, armazenamento local, mapa, login e guia alinhados à edição-piloto.
- Consultas da API de pontos e eventos filtradas para Eunápolis; isso evita expor referências de outras localidades que porventura existam em um banco antigo, sem apagar esses dados.
- Documentos e dados de outras localidades removidos do pacote-fonte.

## Testes executados

- `npm run build`: **passou** (Vite, build de produção).
- `node --check`: **passou** nos módulos client/server relevantes.
- Consistência estática: **16 IDs** no frontend e **16 registros** no seed; os cinco códigos de tag (`eu-001`, `eu-002`, `eu-003`, `eu-004`, `eu-011`) correspondem aos IDs do catálogo.
- Migração de `localStorage`: **passou**; dados legados de exemplo foram reduzidos aos IDs de Eunápolis e a nova chave local foi criada.
- API: endpoints de caderneta, tags e cartões/eventos filtram `cidade_id = eunapolis`.
- Busca residual em código/documentação: **nenhuma referência a outras cidades**; ocorrência de “Prado” é o nome de um ponto local de Eunápolis.
- Inicialização real do MySQL: **não executada**, pois Docker/MySQL não está disponível neste ambiente.

## Pendências de campo

As coordenadas no OpenStreetMap são referências, não validação presencial. Os cinco QR são para teste e devem permanecer pendentes. O catálogo não afirma que a rota, acesso, horários, segurança, acessibilidade ou autorizações estejam validados. Para bases antigas, o código não apaga registros: apenas restringe as respostas da API ao piloto Eunápolis.
