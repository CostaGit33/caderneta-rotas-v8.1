# GitHub Pages — V8.1

A build `build:pages` ativa `VITE_DEMO_MODE=true`. Isso desativa chamadas ao backend para fluxos locais de conta, carimbos e sincronização. O progresso persiste apenas no `localStorage` do navegador.

## Checklist antes de publicar
- [ ] Fazer upload de todo o projeto para GitHub.
- [ ] Selecionar GitHub Actions em Settings → Pages.
- [ ] Confirmar que a workflow terminou com sucesso.
- [ ] Testar em celular e desktop: cadastro, login, mapa, navegação, carimbo local e atualização de página.
- [ ] Confirmar que os dados não aparecem em outro navegador/dispositivo (limitação esperada do demo).
- [ ] Não instalar tags públicas nem usar esta versão para comprovar visitas.

## Para sair da demonstração
Hospede a API Express e o MySQL separadamente, configure CORS e cookies/HTTPS corretamente e altere a aplicação para usar uma URL de API configurável. Não basta publicar `server/` no GitHub Pages.
