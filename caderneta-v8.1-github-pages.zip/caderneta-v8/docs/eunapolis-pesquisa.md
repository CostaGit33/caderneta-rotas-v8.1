# Pesquisa local — Eunápolis, Bahia

## Identificação municipal

- Município: Eunápolis, Bahia.
- Código IBGE: **2910727**.
- Região: Extremo Sul da Bahia.
- População registrada na pesquisa: **113.710**, Censo 2022 do IBGE.
- Emancipação: **12 de maio de 1988**.
- Referência histórica: Km 64 e ligações BR-367/BR-101, conforme material municipal previamente catalogado.

## Meta de cadastro: 40 pontos

A meta é cadastrar 40 pontos locais. A V8 preserva 16 registros locais que estavam disponíveis na V7; eles têm níveis diferentes de evidência e vários ainda precisam de conferência. A meta não significa que 40 pontos tenham sido identificados ou aprovados. Os 24 registros restantes aguardam dados fornecidos e validação; não foram substituídos por nomes ou coordenadas inventados.

| ID | Ponto | Informação preservada | Pendências principais |
|---|---|---|---|
| EU-001 | Praça da Bandeira | Uso cívico documentado; referência OSM `-16.3751286, -39.5881012` | Confirmar coordenada, acesso, segurança, autorização e QR em campo |
| EU-002 | Praça da Liberdade | Requalificação municipal; referência OSM `-16.3734370, -39.5905262` | Confirmar coordenada, acesso, segurança, autorização e QR em campo |
| EU-003 | Parque Ecológico do Gravatá | Parque urbano descrito com lagos e pista de caminhada | Coordenada, condição atual, horário, acesso e segurança |
| EU-004 | Praça do Pequi | Intervenção municipal; referência OSM `-16.3714765, -39.5779847` | Confirmar coordenada, acesso, segurança, autorização e QR em campo |
| EU-005 | Praça do Parque da Renovação | Referência a intervenção municipal | Endereço, estado e operação |
| EU-006 | Praça da Colônia | Praça requalificada no distrito de Colônia | Endereço, acesso e condição atual |
| EU-007 | Praça Dona Dinah Borges Moura | Registro de pista de caminhada de 160 m | Condição atual, horário e acesso |
| EU-008 | Lagoa e Academia da Saúde do Dinah Borges | Pista descrita em restauração | Condição, acesso e extensão oficial |
| EU-009 | Mercado Municipal Dona Alzira | Referência à Feira do Bueiro | Reforma, endereço e horário |
| EU-010 | Feira Livre Juca Rosa | Referência secundária | Localização, calendário e funcionamento |
| EU-011 | Viola de Bolso Arte e Memória | Fonte institucional do espaço cultural | Endereço, responsável, horário, visitação e autorização |
| EU-012 | Prado da Rua Paulo de Tarso | Referência a patrimônio cultural imaterial municipal | Operação, visitação e condições |
| EU-013 | Estrada da Colônia · ciclofaixa | Cerca de 6 km mencionados na pesquisa V7 | Endpoints, tráfego, segurança e validação de rota |
| EU-014 | Circuito Sesc de Corridas | Referência a evento temporal | Confirmar edição/data; não é ponto permanente sem revisão |
| EU-017 | Cruz da primeira missa · proposta | Proposta editorial | Situação jurídica e localização |
| EU-019 | Track comunitário de pedal · candidato | Candidato sem evidência suficiente | Traçado, acesso, superfície e segurança |

As referências cartográficas servem para orientar a vistoria, não para atestar posição exata. Não atribuir horários, acesso público, segurança, acessibilidade ou autorização sem fonte atual.

## Modelo mínimo por ponto

Cada cadastro deve conter: ID estável, nome oficial, categoria, endereço ou referência, latitude/longitude e precisão quando disponível, tipo de coordenada, fonte e evidência, ressalvas, status, data da última verificação, responsável, acesso/horário, avaliação de risco e situação de autorização de QR.

Status aceitos nesta etapa: `pendente`, `validado`, `suspenso` e `fora_da_edicao`. Coordenada ausente deve permanecer nula.

## Fontes

- [Prefeitura de Eunápolis — dados municipais](https://www.eunapolis.ba.gov.br/site/dadosmunicipais)
- [IBGE — Eunápolis](https://www.ibge.gov.br/cidades-e-estados/ba/eunapolis.html)
- [Prefeitura — Praça da Liberdade](https://www.eunapolis.ba.gov.br/Site/Noticias/noticia-180720251513201633-Prefeitura-requalifica-Pra-a-da-Liberdade-e-espa-o-volta-a-ser-local-de-l)
- [Prefeitura — praças do Pequi e Parque da Renovação](https://www.eunapolis.ba.gov.br/site/Noticias/noticia-220420260959481633-Prefeitura-de-Eun-polis-investe-na-revitaliza-o-das-Pra-as-do-Pequi-e-Par)
- [Câmara Municipal — Parque Gravatá](https://www.camaraeunapolis.ba.gov.br/site/Noticias/noticia-190320251006002476-Vereador-pede-revitaliza-o-do-Parque-Ecol-gico-do-Gravat-em-Eun-polis)
- [Viola de Bolso — sobre](https://violadebolso.org.br/about/)
- [Radar64 — notícias locais](https://radar64.com/)

O Radar64 está incluído como referência de notícias locais; verificar data e contexto de cada notícia antes de atualizar cadastro operacional.
