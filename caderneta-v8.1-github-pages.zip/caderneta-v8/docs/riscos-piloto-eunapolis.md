# Riscos e controles · piloto Eunápolis

| Risco | Controle | Gatilho de parada |
|---|---|---|
| Meta de 40 preenchida com dados inferidos | Manter desconhecidos como nulos/pendentes; revisão de fonte | Nome, coordenada ou status sem evidência |
| Ponto apresentado como validado sem vistoria | Ficha de campo por ponto | Divergência de endereço, acesso ou condição |
| QR copiado ou compartilhado | Usar códigos somente em teste; criar rotação e revogação antes da instalação | Código exposto ou atividade anômala |
| Rota insegura ou imprecisa | Não exibir navegação antes de medir e vistoriar | Trecho sem avaliação ou risco não controlado |
| QR instalado sem autorização | Registrar autorização e responsável | Ausência de autorização documentada |
| Horários ou funcionamento desatualizados | Confirmar com responsável e registrar validade | Obra, fechamento ou informação conflitante |
| Progresso local confundido com carimbo auditado | Informar o limite local; testar banco e sincronização | Divergência entre navegador e servidor |
| Dados pessoais usados sem consentimento | Testar com dados fictícios; definir consentimento e retenção | Coleta sem finalidade ou incidente |
| Catálogo crescer sem qualidade | Congelar padrão de evidência; revisão dos novos cadastros | Novo item sem fonte mínima |

## Decisão da V8

Meta de cadastro: 40 pontos de Eunápolis. Os 16 registros preservados são candidatos documentados em níveis diferentes; cinco tags de demonstração permanecem `pendente`. Não instalar QR nem anunciar rota pública até as validações e autorizações necessárias.

Suspender o ponto ou o teste diante de risco não controlado, localização divergente, autorização ausente, QR comprometido, exposição indevida de dados ou impossibilidade de registrar os resultados.
