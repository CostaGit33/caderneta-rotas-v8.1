# Prontidão do piloto Eunápolis · meta 40

## Estado atual

A V8 está fixada em Eunápolis e registra a meta de 40 pontos. O catálogo contém 16 registros locais preservados da V7; o restante aguarda cadastro. Os registros não equivalem a aprovações de campo. Cinco pontos têm tags de teste no banco, todas com status `pendente`.

A interface ainda mantém parte do progresso no navegador. A API de tags/back-end não deve ser confundida com validação física, e um QR não comprova presença.

## Banco

- `cidades`: identificação municipal, código IBGE, UF, região e `meta_pontos=40`.
- `pontos`: ID, nome, categorias, coordenadas nulas ou referenciais, tipo, evidência, fonte, observação e status.
- `rotas` e `tags`: edição-piloto e cinco códigos de teste pendentes.
- `carimbos`: registros gerados nos fluxos de backend existentes.

O seed é idempotente e não remove dados. Para teste limpo, usar um banco de desenvolvimento vazio. Não inserir dados pessoais reais em testes locais.

## Bloqueios antes da operação pública

1. Completar o cadastro até 40 sem preencher lacunas por inferência.
2. Validar presencialmente nome, endereço e coordenada de cada ponto.
3. Registrar responsável, autorização, acesso, horários, acessibilidade conhecida e riscos.
4. Medir e testar a geometria da rota antes de apresentar navegação.
5. Trocar códigos previsíveis de demonstração por códigos aleatórios e revogáveis.
6. Integrar estado de progresso com fonte de verdade no servidor se o piloto exigir persistência entre dispositivos.
7. Definir privacidade, consentimento, suporte, backups e resposta a incidentes.

## Critério de prontidão

Só declarar um ponto operacional após evidência documentada, validação de campo e autorização apropriada. A meta de 40 é uma meta de cadastro, não uma alegação de que 40 pontos já estejam disponíveis.
