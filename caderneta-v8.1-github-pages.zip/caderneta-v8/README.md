# Eunápolis · Experiências locais — V8.1

Versão estática para demonstração e validação visual no GitHub Pages. O piloto concentra-se em Eunápolis (BA). O catálogo contém registros documentados, não uma lista de 40 locais já validados em campo.

## O que muda na V8.1

- Build Vite com caminhos relativos, compatíveis com repositórios de projeto no GitHub Pages.
- Workflow GitHub Actions em `.github/workflows/deploy-pages.yml` para compilar e publicar automaticamente.
- Modo de demonstração local: criar conta, entrar, alterar perfil e conquistar pontos guardam o estado apenas no navegador.
- Mapa usa os tiles públicos do OpenStreetMap, sem depender do endpoint de tiles da API própria.
- Removido o service worker genérico que interceptava e armazenava respostas GET sem separar API de conteúdo estático.
- Identidade visível neutralizada para “Eunápolis · Experiências locais”; a marca definitiva permanece em aberto.

## Publicar no GitHub Pages

1. Extraia o ZIP e envie o conteúdo para a raiz de um repositório GitHub.
2. Faça push para a branch `main` ou `master`.
3. No GitHub, abra **Settings → Pages** e escolha **GitHub Actions** como origem da publicação.
4. Acompanhe **Actions → Publicar V8.1 no GitHub Pages**. Ao terminar, abra a URL apresentada pelo GitHub.

Compilação manual (Node.js 20 ou superior):

```bash
npm ci --prefix client
npm --prefix client run build:pages
```

Os arquivos publicados estarão em `client/dist/`.

## Limitações importantes do GitHub Pages

GitHub Pages hospeda arquivos estáticos; não executa Express/Node.js, não hospeda MySQL e não fornece API. Nesta build, autenticação, perfil e carimbos são demonstrações locais em `localStorage`: ficam no mesmo navegador/dispositivo e não sincronizam entre pessoas ou aparelhos. Não use dados reais/sensíveis e não trate esses carimbos como prova de visita física. A leitura de tags NFC/QR integrada ao servidor, as sessões compartilhadas, os eventos e a persistência central exigem publicar `server/` em um serviço com backend e banco de dados e configurar a URL da API.

O mapa utiliza tiles públicos do OpenStreetMap. Respeite a política de uso do serviço e não gere tráfego excessivo.

## Desenvolvimento completo com backend

A estrutura `server/`, o Docker Compose e as migrações foram preservados para o desenvolvimento com API e MySQL. Para executar o projeto integrado, configure `server/.env` a partir de `server/.env.example` e consulte `docs/verificacao-v8.md`. A build Pages é um modo de demonstração separado.

## Situação do catálogo de Eunápolis

A meta editorial é 40 pontos; os registros documentados não equivalem a 40 locais aprovados. Endereço, coordenadas, acesso, horário, segurança, acessibilidade, autorização e operação precisam ser confirmados presencialmente. Os QR codes de demonstração não devem ser instalados publicamente.
